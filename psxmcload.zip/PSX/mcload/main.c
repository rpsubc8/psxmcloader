/*************************************************************************/
/* Programa: MCLOADER v1.0                                               */
/* Autor: ackerman                                                       */
/* MC es la abreviacion de Memory Card o tarjeta de memoria.             */
/* Este programa permite cargar un .EXE empaquetado y troceado en varias */
/* tarjetas, por la utilidad MCTOOL v1.0, en la propia PSOne.            */
/*************************************************************************/

#include <kernel.h>
#include <sys/file.h>
#include <sys/types.h>  //these are the various include files that need to be included
#include <libetc.h>		//note that the order they are included in does matter in some cases!
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <stdio.h>
#include <libmcrd.h>
#include "pad.h"
#include "cardio.h"

#define OT_LENGTH (10) //this is the 'length' of the OT (ordering tabble)
					   //for more info on ordering tables, check out ot.txt on my 'info' page
#define PACKETMAX (2048) //these are the graphics area contants
#define PACKETMAX2 (PACKETMAX*24) //allows you to select how many gfx objects the psx should handle
             					  //in this particular example

#define SCREEN_WIDTH 320 //contants to determine the height and width of the screen resolution
#define SCREEN_HEIGHT 240
#define max_buffer_memoria 4096
#define boolean u_char
#define true 1
#define false 0
#define cabecera_loader 5 //Los 3+2 bytes de la cabecera
#define offset_slot1 0x200
#define H_SIZE 2048
enum tipo_unidades{unidad1,unidad2,unidad12,unidad21};

u_char cab_p_exe[8]={0x50,0x53,0x2D,0x58,0x20,0x45,0x58,0x45};
u_char mensaje_sony[48]={0x53,0x6F,0x6E,0x79,0x20,0x43,0x6F,0x6D,0x70,0x75,0x74,0x65,0x72,
                         0x20,0x45,0x6E,0x74,0x65,0x72,0x74,0x61,0x69,0x6E,0x6D,0x65,0x6E,
                         0x74,0x20,0x49,0x6E,0x63,0x2E,0x20,0x66,0x6F,0x72,0x20,0x45,0x75,
                         0x72,0x6F,0x70,0x65,0x20,0x61,0x72,0x65,0x61};
GsOT myOT[2];				//an array of 2 OT's this is how your double buffering is implemented
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];
PACKET GPUPacketArea[2][PACKETMAX2];	//also 2 gfx packet areas for double buffering
u_long pad;
int activeBuffer=0;		//variable used to hold the buffer that is currently being displayed	
int id_fuente;
//char cad_mcloader[]="********************\n*                  *\n* psxmcloader v1.0 *\n*                  *\n********************\n\n";
char cad_mcloader[]="psxmcloader v1.0\n\n";
char cad_disco[15]={0x82,0x63,0x82,0x68,0x82,0x72,0x82,0x62,0x82,0x6E,0x82,0x4F,0x82,0x50,0x00}; //Contiende disco01
u_char buffer_memoria[max_buffer_memoria];
long fichero;
struct EXEC exe;
char hbuf[H_SIZE];	// Buffer for EXE head
struct XF_HDR *head;
struct EXEC *exep=&exe;

char gb_cad_log[2048] = "LOG:                                           ";
unsigned char auxBuffer[150000];

/***************** prototypes *******************/
void InitGraphics(void);			//this method sets up gfx for printing to screen
void DisplayAll(int);			//this displays the contents of the OT
int main(void);
void (*Reboot)() = (void *)0xbfc00000;
void Carga_inicial(void);
void Cargar_disco1(enum tipo_unidades tipo);
boolean Comprueba_cad_disco(u_char *buffer_memoria);
void CargaPrograma(struct EXEC *exep);


//***********************************************
void CargaPrograma(struct EXEC *exep){
 //memcpy (hbuf, main2,H_SIZE);
 //memcpy((void *)exep->t_addr,&main2[H_SIZE],exep->t_size);
 char hbuf[H_SIZE];	// Buffer for EXE head
 struct XF_HDR *head;
 char cad_aux[2048]="  ";
 memcpy (hbuf, &auxBuffer,H_SIZE);
 head = (struct XF_HDR *)hbuf;
 memcpy((void *)exep, (void *)&head->exec, sizeof(struct EXEC)); 
 memcpy((void *)exep->t_addr,&auxBuffer[H_SIZE],exep->t_size); //El tamanio fichero esta en exep->t_size
 				   
				   
//				   strcpy(gb_cad_log,"LOG:t_size ");
//				   sprintf(cad_aux, "%d", exep->t_size);
//				   strcat(gb_cad_log,cad_aux);
 
 ResetGraph(3);
 PadStop();
 StopCARD();
 StopCallback();
 EnterCriticalSection();
 Exec(&exe,1,0);
}


/***************** functions ********************/
int main(void){
 ResetCallback();
 InitCARD(1);
 StartCARD();
 _bu_init();
 _card_auto(0);
 _card_load(0);
 MemCardAccept(0);
 _card_load(0);
 _card_wait(0);
 
 InitGraphics();			//this method sets up gfx for printing to screen	
 FntLoad(960, 256);		//this loads the font gfx to the vram
 id_fuente=FntOpen(32, 32, 256, 200, 0, 512);	//this sets up the fonts printing attributes 
 Carga_inicial();
 
 ResetGraph(3);
 PadStop();
 StopCallback(); 
 return 0;		//when program is finished return from it
}

/**********************************************************/
void InitGraphics(void){
 //this method sets up gfx for printing to screen
 GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 1, 0); //initialises the graphics system
 //no Gs* * * functions will work unless GsInitGraph() has been called
 GsDefDispBuff(0,0,0,SCREEN_HEIGHT); //defines double buffer attributes
 //buffer 0's top left coordinate becomes (0,0) & buffer 1's coordinate becomes (0, y resolution)
 myOT[0].length= OT_LENGTH; //sets OT length for each OT
 myOT[1].length= OT_LENGTH;
 myOT[0].org= myOT_TAG[0]; //gets top address of GsOT_TAG table
 myOT[1].org= myOT_TAG[1];
 GsClearOt(0,0,&myOT[0]); //initialises ordering table
 GsClearOt(0,0,&myOT[1]);
 PadInit(0);
}

/***************************************************************/
void DisplayAll(int activeBuffer) {
 //this method contains all the functions needed to display the contents of the OT
 FntFlush(-1); //flushes font buffers contents from buffer so that they can be printed to screen
 DrawSync(0);
 //this waits till the GPU has finished drawing, as GsSwapDispBuff will not work correctly if drawing is in progress
 VSync(0);	//gsswapdispbuff should be called after beginning a v-blank
 GsSwapDispBuff(); //swap display buffer
 GsSortClear(0,0,0,&myOT[activeBuffer]); //clears screen to color (0,0,0) and sorts OT ready for drawing
 GsDrawOt(&myOT[activeBuffer]);	//draws the contents of OT to screen
}

/************************************************/
void Carga_inicial(void){
 boolean salir=false;
 char cad[4][24]={"CARD 1 in UNIT 1\n","CARD 2 in UNIT 2\n","CARD 1,2 in UNIT 1,2\n","CARD 1,2 in UNIT 2,1\n"};
 short i;
 boolean tarjeta1,tarjeta2; //Dice si esta la tarjeta1 instalada
 short pos=0;
 if (_card_info(0)==1) tarjeta1=true;
 else tarjeta1=false;
 if (_card_info(1)==1) tarjeta2=true;
 else tarjeta2=false; 
 while(salir==false){
  activeBuffer = GsGetActiveBuff();	//gets the buffer currently being displayed and stores in activeBuffer
  GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);	//sets up the gfx workspace
  GsClearOt(0, 0, &myOT[activeBuffer]);			//clears the OT contents
  FntPrint(id_fuente,cad_mcloader);
  for (i=0;i<4;i++){
   if (pos==i) FntPrint("() ");
   else FntPrint("   ");
   FntPrint(cad[i]);
  }
  FntPrint(id_fuente,"\n UNIT 1: ");
  if (tarjeta1==true) FntPrint(id_fuente,"inserted card\n");
  else FntPrint(id_fuente,"NO card\n");
  FntPrint(id_fuente," UNIT 2: ");
  if (tarjeta2==true) FntPrint(id_fuente,"inserted card\n");
  else FntPrint(id_fuente,"without card\n");  
  FntPrint(id_fuente," \n\n   x OK     o RESET\n\n --------------------------\n  ackerman (sliders group)");
  FntPrint(id_fuente,"\n%s",gb_cad_log);
  pad=PadRead(0);
  if (pad&Pad1Down){//Moverse abajo
   while (pad&Pad1Down) pad=PadRead(0); //Espera a que se libere
   pos++;
  }
  else{
   if (pad&Pad1Up){//Moverse arriba
    while (pad&Pad1Up) pad=PadRead(0); //Espera a que se libere
    pos--;
   }
   else{
    if (pad&Pad1x){//Boton de Aceptar
     while (pad&Pad1x){
 	  pad = PadRead(0);
	 }
     switch (pos){
      case 0: //DisablePad();
	   Cargar_disco1(unidad1);
	   //EnablePad(); 
	   break;
      case 1:Cargar_disco1(unidad2);break;
      case 2:Cargar_disco1(unidad12);break;
      case 3:Cargar_disco1(unidad21); break;
      default:Cargar_disco1(unidad1);
     };
    }
    else{
     if (pad&Pad1crc){//Boton de Reseteo
      while (pad&Pad1crc)  pad=PadRead(0);      
      salir=true;
      Reboot();
     }
    }
   }
  }       
  if (pos<0) pos=0;
  else if (pos>3) pos=3;  
  DisplayAll(activeBuffer);		//this display the OT contents to screen
 }
}



void PrintLog(){
  activeBuffer = GsGetActiveBuff();	//gets the buffer currently being displayed and stores in activeBuffer
  GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);	//sets up the gfx workspace
  GsClearOt(0, 0, &myOT[activeBuffer]);			//clears the OT contents

  FntPrint(id_fuente,gb_cad_log);
  
  DisplayAll(activeBuffer);		//this displays the OT contents to screen
}

/****************************************************/
void Cargar_disco1(enum tipo_unidades tipo){
 //Carga el EXE del disco1 en la unidad dada
 u_char *p_aux;
 boolean salir=false;
 boolean cabecera_dentro=false;
 int aux;
 int i;
 int tam_fichero,total_ceros,contador;
 int cont_memoria=0;
 unsigned int auxSizeFile=0;
 unsigned int auxAddress=0;
 _CARD cardinf;
 //unsigned char auxBuffer[122368]; 
 //unsigned char auxBuffer[150000];
 int m=0;
 int cont=0;
 char cad_aux[2048]="  ";
 

                 _bu_init(); //Test error first read memcard
				 _card_auto(0);
				 _card_load(0);                 
				 MemCardAccept(0);
                 _card_load(0);
                 _card_wait(0);				 

                 fichero=open("bu00:BEMCLOADER-1SLIDERS",O_RDONLY);
				 close(fichero);
				 _bu_init();
				 _card_auto(0);
				 _card_load(0);
                 _card_wait(0);

				 
                 if (fichero=open("bu00:BEMCLOADER-1SLIDERS",O_RDONLY)>0){
				 //if (fichero=open("bu00:BEMC",O_RDONLY)!=-1){				  
	    	      if ((aux = read( fichero, (char*)&cardinf, sizeof( _CARD ))) != sizeof(_CARD)){//Leo cabecera 512 bytes
				  //if ((aux = read( fichero, (unsigned char*)&auxBuffer, 512)) != 512){//Leo cabecera 512 bytes				  
				   strcpy(gb_cad_log,"LOG:Error INFOCARD");
				   sprintf(cad_aux, "%d", aux);
				   strcat(gb_cad_log,cad_aux);
				   salir= true;
				   close(fichero);
				   return;				   
				  }
				  else{//OK 512 bytes cabecera
				   strcpy(gb_cad_log,"LOG:OK");
				   //sprintf(cad_aux, "%d", aux);
				   //strcat(gb_cad_log,cad_aux);
				   //read( fichero, (unsigned char*)&auxBuffer, 128); //Leo 7 bytes tamanio y adddress
				   //lseek(fichero,512+7,SEEK_SET);
				   PrintLog();
				   for (m=0;m<30;m++){
				    aux = read( fichero, (unsigned char*)&auxBuffer[(m*2048)], 2048); //Leo 2 KB
				    if (aux != 2048){
					}
					else{
					 strcpy(gb_cad_log,"BYTES ");
				     sprintf(cad_aux, "%d", (m*2048));
					 strcat(gb_cad_log,cad_aux);
					}
					PrintLog();
				   }
				   
				   close(fichero);
				   CargaPrograma(&exe);
				   
				  }
				 }
				 else{
				  strcpy(gb_cad_log,"LOG:Error Open");
				  close(fichero);
				  return;
				 }
				 
				 close(fichero);
				 


/*//				  FntPrint ("\nMagic %c%c Type %x Blocks %d",cardinf.Magic[0],cardinf.Magic[1],cardinf.Type,cardinf.BlockEntry);			      
				  //Leo 3 bytes tamanio fichero
				  if ((aux = read( fichero, (unsigned char*)&auxBuffer, 128)) != 128){//Leo tamanio fichero
//                   FntPrint("read error.\n");
				   salir= true;
				   strcpy(gb_cad_log,"LOG:Error 128");
				   return;
				  }
				  auxSizeFile = auxBuffer[0]+(auxBuffer[1]<<8)+(auxBuffer[2]<<16); //Tamanio fichero
                  auxAddress = auxBuffer[3]+(auxBuffer[4]<<8)+(auxBuffer[5]<<16)+(auxBuffer[6]<<24); //Salto direccion
				  //512 bytes Head + 128 bytes 
				  //8192 * 15  = 122880 - 512 = 122368 - 128 = 122240 - 7 bytes de address y tamanio fichero
				  lseek(fichero,512,SEEK_SET); //Vuelvo a donde la cabecera de 512 bytes
				  for (m=0;m<1;m++){
			       //aux = read( fichero, (unsigned char*)&auxBuffer, ((8192*2)-512)); //Leo toda la tarjeta
				   aux = read( fichero, (unsigned char*)&auxBuffer, 512); //Leo 2 KB
				   if (aux != 512){
 //				   FntPrint("read error %d.\n",aux);
				    strcpy(gb_cad_log,"LOG:Error 512");
				    salir= true;				   
				    return;			   
				   }
				   else
				   {
//				    FntPrint("Bytes leidos %d.\n",aux);
				    strcpy(gb_cad_log,"LOG:OK");
					PrintLog();
				   }
				  }
				  cont++;				  
				  


                   }
                   else{
                    //FntPrint("error!! inserte el disco01\n");
					strcpy(gb_cad_log,"LOG:ERROR abrir");
                   }                    			  
                  }	
                  close(fichero);
                 }
                 else
				 {
//				  FntPrint("error al leer fichero disco01\n");
				  salir= true;
				  close(fichero);
				  return;
				 }                 
  };
  
  close(fichero);
 } 
 close(fichero);
 */
}

/************************************************************/
boolean Comprueba_cad_disco(u_char *buffer_memoria){
 //Comprueba el nombre del disco a partir de la cabecera
 //Le tenemos que pasar el buffer con la primera lectura del archivo, que tiene
 //varios bytes de mas, como SC
 short int i;
 i=0;
 while (i<sizeof(cad_disco)){
  if (buffer_memoria[i+4] != cad_disco[i]) return (false);
  i++;
 }
 return (true);
}



//Lanzar exe
//    ResetGraph(3);
//    PadStop();
//	StopCallback();
//	EnterCriticalSection();
//     Exec(&exe,1,0);                    





 //cad_disco[11]=0x4F; cad_disco[13]=0x50; //Pone disco01
 //while(salir==false)
// {    
//  activeBuffer = GsGetActiveBuff();	//gets the buffer currently being displayed and stores in activeBuffer
//  GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);	//sets up the gfx workspace
//  GsClearOt(0, 0, &myOT[activeBuffer]);			//clears the OT contents
  //FntPrint(id_fuente,cad_mcloader);
//  FntPrint(id_fuente,"\nCont %d\n"+cont);
//  switch (tipo){
//   case unidad1: //FntPrint("UNIT 1 ");


//Deprecated


				  //aux=read(fichero,(u_char*)&cardinf,4);//Leo 2048 bytes
                  //aux=read(fichero,(u_char*)&buffer_memoria,sizeof(buffer_memoria));//Leo 2048 bytes
				  //FntPrint(id_fuente,"%d bytes",aux);
/*                  if (aux!= sizeof(buffer_memoria)){
				   FntPrint(id_fuente,"error al leer el disco\n");
				  }
                  else{
                   if (Comprueba_cad_disco(buffer_memoria)==true){//Para saber si es el disco				   
                    FntPrint("disco01\n");
                    //Miro la cabecera el nombre del 
                    aux=buffer_memoria[offset_slot1]; aux=(aux<<16);tam_fichero=aux;
                    aux=buffer_memoria[offset_slot1+1]; aux=(aux<<8);tam_fichero+=aux;
                    tam_fichero+=buffer_memoria[offset_slot1+2];                    
                    FntPrint("exe  %d Bytes\n",tam_fichero);
                    FntPrint("%d KB   %d MB\n",(tam_fichero>>10),(tam_fichero>>20));
                    aux=buffer_memoria[offset_slot1+3]; 
                    if ((aux&0x40)==0x40){cabecera_dentro=true; FntPrint("cabecera incluida\n");}
                    else{cabecera_dentro=false;FntPrint("cabecera no incluida\n");}
                    aux=(aux<<8);total_ceros=aux;
                    total_ceros+=buffer_memoria[offset_slot1+4];
                    FntPrint("0's: %d Bytes\n",total_ceros);
                    cont_memoria=0;
                    bzero(hbuf,sizeof(hbuf));
                    memcpy(hbuf,cab_p_exe,sizeof(cab_p_exe));//Copia la cabecera del EXE
                    if (cabecera_dentro==false){for (i=8;i<=0x0F;i++) hbuf[i]=0;}
                    else{for (i=8;i<=0x0F;i++) hbuf[i]=buffer_memoria[offset_slot1+i-8+cabecera_loader]; cont_memoria=0x10;}
                    for (i=0x10;i<=0x4B;i++) hbuf[i]=buffer_memoria[offset_slot1+i-0x10+cabecera_loader+cont_memoria];
                    cont_memoria+=0x3C;
                    for (i=0x4C;i<=0x7B;i++) hbuf[i]=mensaje_sony[i-0x4C];
                    //cont_memoria+=0x30;
                    if (cabecera_dentro==false){for (i=0x7C;i<=0x7FF;i++) hbuf[i]=0;}
                    else{
                     for (i=0x7C;i<=0x7FF;i++) hbuf[i]=buffer_memoria[offset_slot1+i-0x7C+cabecera_loader+cont_memoria];
                     cont_memoria+=0x784;
                    }                    
                    head = (struct XF_HDR *)hbuf;
                    memcpy((void *)exep, (void *)&head->exec, sizeof(struct EXEC));
                    //FntPrint("HSIZE %d Bytes\n",H_SIZE);
                    FntPrint("Dir 0x%x\n",exep->t_addr);
                    FntPrint("Tam %d Bytes\n",exep->t_size);
                    for (i=0x7FC;i<0x7FF;i++) FntPrint("%x ",hbuf[i]);
                    //Copio a la direccion de memoria
                    i=0x800;
                    contador=max_buffer_memoria-(offset_slot1+cabecera_loader+cont_memoria);
                    memcpy((void *)exep->t_addr,&buffer_memoria[offset_slot1+cabecera_loader+cont_memoria],contador);                    
                    p_aux=(u_char *)(exep->t_addr);
                    cont_memoria+=(max_buffer_memoria-i);                    
                    while (cont_memoria<(tam_fichero-total_ceros)){
                     //Leemos el resto de EXE
                     aux=read(fichero,(u_char*)&buffer_memoria,sizeof(buffer_memoria));//Leo 2048 bytes
                     memcpy(&p_aux[contador],&buffer_memoria,max_buffer_memoria);
                     cont_memoria+=max_buffer_memoria;
                     contador+=max_buffer_memoria;
                    }                    
                    bzero(p_aux[contador],total_ceros);//Lleno de 0's lo que falta
                    FntPrint("%d ",cont_memoria);
                    for(i=0;i<0x60;i++){
                     if (p_aux[i]<=0xF) FntPrint("0");
                     FntPrint("%x",p_aux[i]);
                    }
*/					