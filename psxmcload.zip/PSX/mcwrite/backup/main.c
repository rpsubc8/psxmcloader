/***********************************************************************/
/* Programa: PSXMCWRITER                                               */
/* Autor: ackerman                                                     */
/* Grupo: Sliders                                                      */
/* Programa de utilidad para prueba de grabar en MC uno o varios slots */
/* para poder sacar las posiciones de los archivos .MCR para hacer el  */
/* resto de herramientas como el loader                                */
/* La cabecera (HEAD) de la MC es de 512 bytes.A partir de ahi,van los */
/* datos                                                               */
/* En el archivo .MCR de la MC del emulador los datos empiezan a partir*/
/* de la posicion 0x2200.                                              */
/* El slot de un juego los datos empiezan en 512 y acaban en 8192,luego*/
/* se aprobecha solo 7680 bytes del slot1.El resto de slots no afecta  */
/* Luego 14 slots * 8192 bytes= 114688 bytes + 7680= 122368 bytes      */
/* Dentro del .MCR los datos se encuentran en cada slot en el offset   */
/*  slot  1: 0x02200 -->  8704                                         */
/*  slot  2: 0x04000 --> 16384                                         */
/*  slot  3: 0x06000 --> 24576                                         */
/*  slot  4: 0x08000 --> 32768                                         */
/*  slot  5: 0x0A000 --> 40960                                         */
/*  slot  6: 0x0C000 --> 49152                                         */
/*  slot  76 0x0E000 --> 57344                                         */
/*  slot  8: 0x10000 --> 65536                                         */
/*  slot  9: 0x12000 --> 73728                                         */
/*  slot 10: 0x14000 --> 81920                                         */
/*  slot 11: 0x16000 --> 90112                                         */
/*  slot 12: 0x18000 --> 98304                                         */
/*  slot 13: 0x1A000 --> 106496                                        */
/*  slot 14: 0x1C000 --> 114688                                        */
/*  slot 15: 0x1E000 --> 122880                                        */
/***********************************************************************/

#include <kernel.h>
#include <libapi.h>

#include <sys/types.h>		//these are the various include files that need to be included
#include <sys/file.h>
//#include "cardio.h"
#include <libetc.h>		//note that the order they are included in does matter in some cases!
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <stdio.h>
#include "pad.h"
//#include "main2.h"
#include "kk.h"

#include "hand1.h"
#include "hand2.h"
#include "hand3.h"

#define H_SIZE 2048
#define true 1
#define false 0

typedef	struct{	int	fileEntry; char	fileName[15][64]; } _FINF;
typedef struct{ char Magic[2]; char Type; char BlockEntry; char	Title[64]; char	reserve[28]; char Clut[32];	char Icon[3][128];} _CARD;

typedef	struct {
 long id; long flag; long cbnum; short cx; short cy; short cw; short ch; char clut[32];
 long pbnum; short px; short py; short pw; short ph; char image[2];
} _TIM4;
_CARD HEAD;


unsigned char buf[122880];

/*
also note that while this example uses the Gs functions, these are high level functions
and should not be used if it can be helped as they are quite slow and consume lots of memory.
they will however do while you are learning as they simplify things and help you to understand
the process that you go through to print to the screen.
*/

#define OT_LENGTH (10)			//this is the 'length' of the OT (ordering tabble)
					//for more info on ordering tables, check out ot.txt on my 'info' page

#define PACKETMAX (2048)		//these are the graphics area contants
#define PACKETMAX2 (PACKETMAX*24)	//allows you to select how many gfx objects the psx should handle
					//in this particular example

#define SCREEN_WIDTH 320		//contants to determine the height and width of the screen resolution
#define SCREEN_HEIGHT 240

GsOT myOT[2];				//an array of 2 OT's this is how your double buffering is implemented
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];
PACKET GPUPacketArea[2][PACKETMAX2];	//also 2 gfx packet areas for double buffering
u_long pad;
struct EXEC exe;
u_char salir;
char cadena_texto[512];
int i;

/***************** prototypes *******************/
void InitGraphics(void);			//this method sets up gfx for printing to screen
void DisplayAll(int);			//this displays the contents of the OT
int main(void);
void HandlePad(void);
void CargaPrograma(struct EXEC *exep);
void (*Reboot)() = (void *)0xbfc00000;
void MakeBackupCard( char* fname, int type, char* name, u_long* clut,
		    u_long* image1, u_long* image2, u_long* image3,
		    long length );


/***************** functions ********************/
int main(void) {
	int activeBuffer=0;		//variable used to hold the buffer that is currently being displayed
    salir=false;
    ResetCallback();
    InitCARD(1);
    StartCARD();
    _bu_init();
    _card_auto(1);		   
    

	InitGraphics();			//this method sets up gfx for printing to screen
	
	FntLoad(960, 256);		//this loads the font gfx to the vram
	FntOpen(32, 32, 256, 200, 0, 512);	//this sets up the fonts printing attributes
						//eg printing boundries and number of letters to hold in printing buffer etc
						
   while (salir!=true) {				//infinite loop
   		HandlePad();					//this handles button presses on the controller pad 1
		activeBuffer = GsGetActiveBuff();	//gets the buffer currently being displayed and stores in activeBuffer
		GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);	//sets up the gfx workspace
		GsClearOt(0, 0, &myOT[activeBuffer]);			//clears the OT contents		
		DisplayAll(activeBuffer);		//this dispalys the OT contents to screen
	}
    CargaPrograma(&exe);
    ResetGraph(3);
    PadStop();
	StopCallback();
	EnterCriticalSection();
     Exec(&exe,1,0);
	return 0;		//when program is finished return from it
}

void InitGraphics(void) {
	//this method sets up gfx for printing to screen
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 1, 0); //initialises the graphics system
	//no Gs* * * functions will work unless GsInitGraph() has been called
	GsDefDispBuff(0, 0 , 0, SCREEN_HEIGHT); //defines double buffer attributes
	//buffer 0's top left coordinate becomes (0,0) & buffer 1's coordinate becomes (0, y resolution)

	myOT[0].length = OT_LENGTH; //sets OT length for each OT
	myOT[1].length = OT_LENGTH;
	myOT[0].org = myOT_TAG[0]; //gets top address of GsOT_TAG table
	myOT[1].org = myOT_TAG[1];
	GsClearOt(0,0,&myOT[0]); //initialises ordering table
	GsClearOt(0,0,&myOT[1]);
	PadInit(0);	
}

void DisplayAll(int activeBuffer) {
	//this method contains all the functions needed to display the contents of the OT
	FntFlush(-1);				//flushes font buffers contents from buffer so that they can be printed to screen
	DrawSync(0);
	//this waits till the GPU has finished drawing, as GsSwapDispBuff will not work correctly if drawing is in progress
	VSync(0);					//gsswapdispbuff should be called after beginning a v-blank
	GsSwapDispBuff();				//swap display buffer
	GsSortClear(0,0,0,&myOT[activeBuffer]);		//clears screen to color (0,0,0) and sorts OT ready for drawing
	GsDrawOt(&myOT[activeBuffer]);			//draws the contents of OT to screen
}

/***********************************************/
void HandlePad(void) {
 //handles button presses
// u_char *datos;
 pad=PadRead(0);
 if (pad&Pad1Left) FntPrint("Izquierda");
 if (pad&Pad1Right) FntPrint("Derecha");
 //La B es de Magic Number
 //La E de Europa y el resto el nombre del fichero
 if (pad&Pad1Up) MakeBackupCard( "bu00:BEMCLOADER-1SLIDERS", 0x13, "JAIME",
		   (u_long *)(((_TIM4*)hand1)->clut),
		   (u_long *)(((_TIM4*)hand1)->image),
		   (u_long *)(((_TIM4*)hand2)->image),
		   (u_long *)(((_TIM4*)hand3)->image), (long)(8192*15));

 if (pad&Pad1Down){
  FntPrint("Cargar");
//  FntPrint(" %d ",exe.t_addr);
//  datos=(u_char *)exe.t_addr;
//  FntPrint(" %d ",datos[0]);
  salir=true;
 }
}

/***********************************************/
void CargaPrograma(struct EXEC *exep){
 char hbuf[H_SIZE];	// Buffer for EXE head
 struct XF_HDR *head;
 memcpy (hbuf, main2,H_SIZE);
 head = (struct XF_HDR *)hbuf;
 memcpy((void *)exep, (void *)&head->exec, sizeof(struct EXEC));
 memcpy((void *)exep->t_addr,&main2[H_SIZE],exep->t_size);
}

void MakeBackupCard(char* fnam, int type, char* name, u_long* clut,
		    u_long* image1, u_long* image2, u_long* image3,
		    long length ){
    long  fd;
    long  totalbytes;
//    long  totalblock;
    _CARD cardinf;

    int i, j;
    unsigned char *cp;

//    for (i = 0; i < 256; i++)
    for (j = 0; j < sizeof(buf); j++) //Limpia la MC
     buf[j]=0;
     buf[512]='R'; //Donde empiezan los datos del primer slot
     buf[513]='O';buf[514]='S';buf[515]='I';
    for (j=1;j<16;j++){
     buf[j*8192]='R'; //Donde empiezan los datos
     buf[(j*8192)+1]='O';buf[(j*8192)+2]='S';buf[(j*8192)+3]='I';
    }

    totalbytes = ((length/8192) * 8192) + (length%8192 ? 8192:0 );

    HEAD.Magic[0] = 'S';
    HEAD.Magic[1] = 'C';
    HEAD.Type = type;
    HEAD.BlockEntry = ( totalbytes/8192  )+( totalbytes%8192 ? 1:0 );
    strcpy( HEAD.Title, name );
    memcpy( HEAD.Clut, clut, 32 );
    if (type == 0x13) {
	memcpy( HEAD.Icon[0], image1, 128);
	memcpy( HEAD.Icon[1], image2, 128);
	memcpy( HEAD.Icon[2], image3, 128);
    } else {
	memcpy( HEAD.Icon[0], image1, 128 );
	memcpy( HEAD.Icon[1], image1, 128 );
	memcpy( HEAD.Icon[2], image1, 128 );
    }
    
    memcpy( buf, &HEAD, sizeof( HEAD ));
    
    if ((fd = open( fnam,  O_CREAT | HEAD.BlockEntry << 16  )) == -1)
      FntPrint("%s open error al crear Cab %dB Long %dB Card %dB.\n", fnam,sizeof(HEAD),totalbytes,sizeof(_CARD));
    FntPrint( "Discript: %d\n", fd );
    close( fd );
    
    if ((fd = open( fnam,  O_WRONLY )) == -1)
      FntPrint("%s open error al escribir.\n", fnam);
    if ((i = write( fd, buf, totalbytes )) != totalbytes)
      FntPrint("write error. %d, %d\n", i, totalbytes);
    close( fd );
    
    if ((fd = open( fnam,  O_RDONLY )) == -1)
      FntPrint("%s open error al leer.\n", fnam);
    if ((i = read( fd, (char*)&cardinf, sizeof( _CARD ))) != sizeof(_CARD))
      FntPrint("read error.\n");
    close( fd );                 
}
