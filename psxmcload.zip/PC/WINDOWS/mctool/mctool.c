//************************************************************************
//* Programa: MCTOOL v1.0
// Autor: ackerman
//* MC es la abreviacion de Memory Card o tarjeta de memoria.
//* Permite crear un archivo en formato .MCR de tipo tarjeta de memoria de
//* PSOne para poder ser leida en los emuladores o poder ser grabada en
//* una MC real.                                                          *
//* Dentro tiene un archivo .EXE de PSOne que pueden ser leido con el     *
//* PSXMCLOADER para cargar homebrew.Puede estar fragmentado en varias MC *
//* de forma que crea un .MCR con nombre fuera y dentro del slot referido *
//* a cada disco, ejemplo:                                                *
//*  DISCO01 --> Es el disco o memoria 1                                  *
//*  DISCO02 --> Es el disco o memoria 2                                  *
//*  DISCO16 --> Es el ultimo disco o memoria soportado                   *
//* Dentro del .MCR el nombre del archivo DISCO01 esta en el offset 0x2004*
//* Y esta en codificacion Shift-JIS, que empieza por el codigo 0x82 y por*
//* cada letra hay otro 0x82, menos la ultima que es 0x0.Los numeros de   *
//* DISCO empiezan en el offset 0x200F,y el valor 0 es 0x4F,1 es 0x50.    *
//* Genera una cabecera de 5 bytes en los datos del slot1:                *
//*  3 bytes --> Tamanio en bytes del archivo                             *
//*  4 Bytes --> Direccion memoria salto 0x80010000                       *
//*  Deprecated 2 bytes --> 1 bit --> Poner o no la HEAD del EXE          *
//*  Deprecated 15 bits --> Numero de 0's que hay al final del EXE        *
//*  Luego van los datos del EXE de PSOne en ristra.                      *
//* El EXE tiene siempre los mismos datos desde el offset 0x0 hasta 0x0F  *
//* incluidos ambos. Y desde 0x4C hasta 0x7FF, en donde esta el mensaje de*
//* SONY Europa o America                                                 *
//*                                                                       *
//* La cabecera de la MC es de 512 bytes.A partir de ahi,van los datos    *
//* En el archivo .MCR de la MC del emulador los datos empiezan a partir  *
//* de la posicion 0x2200.                                                *
//* El slot de un juego los datos empiezan en 512 y acaban en 8192,luego  *
//* se aprobecha solo 7680 bytes del slot1.El resto de slots no afecta    *
//* Luego 14 slots * 8192 bytes= 114688 bytes + 7680= 122368 bytes        *
//* Dentro del .MCR los datos se encuentran en cada slot en el offset     *
//*  slot  1: 0x02200 -->  8704                                           *
//*  slot  2: 0x04000 --> 16384                                           *
//*  slot  3: 0x06000 --> 24576                                           *
//*  slot  4: 0x08000 --> 32768                                           *
//*  slot  5: 0x0A000 --> 40960                                           *
//*  slot  6: 0x0C000 --> 49152                                           *
//*  slot  76 0x0E000 --> 57344                                           *
//*  slot  8: 0x10000 --> 65536                                           *
//*  slot  9: 0x12000 --> 73728                                           *
//*  slot 10: 0x14000 --> 81920                                           *
//*  slot 11: 0x16000 --> 90112                                           *
//*  slot 12: 0x18000 --> 98304                                           *
//*  slot 13: 0x1A000 --> 106496                                          *
//*  slot 14: 0x1C000 --> 114688                                          *
//*  slot 15: 0x1E000 --> 122880                                          *
//*                                                                       *
//* El maximo tamanio del fichero del .EXE es de 1900000 bytes            *
//* Ejemplo de lanzar programa:                                           *
//*  mctool psx.exe                                                       *
//* y automaticamente nos generara 1 o varios .MCR con el psx.exe dentro  *
//* Para compilar:                                                        *
//*  gcc -s -O6 mctool.c -omctool.exe                                     *
//*************************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "memoria.h"
#define byte unsigned char
#define max_buffer 1900000
#define max_tarjeta 131072
#define boolean unsigned char
#define true 1
#define false 0
#define offset_cabecera_mc 512 //cabecera psx con el clu animacion
#define cabecera_propia 7 //3 bytes tamanio exe y 4 bytes salto
#define offset_slot1 0x2200
#define offset_slot2 0x4000
#define offset_slot3 0x06000
#define offset_slot4 0x08000
#define offset_slot5 0x0A000
#define offset_slot6 0x0C000
#define offset_slot7 0x0E000
#define offset_slot8 0x10000
#define offset_slot9 0x12000
#define offset_slot10 0x14000
#define offset_slot11 0x16000
#define offset_slot12 0x18000
#define offset_slot13 0x1A000
#define offset_slot14 0x1C000
#define offset_slot15 0x1E000

//#define BITS 14                   // Setting the number of bits to 12, 13
//#define HASHING_SHIFT (BITS-8)    // or 14 affects several constants.
//#define MAX_VALUE (1 << BITS) - 1 // Note that MS-DOS machines need to
//#define MAX_CODE MAX_VALUE - 1    // compile their code in large model if
//                                  // 14 bits are selected.
//#if BITS == 14
//  #define TABLE_SIZE 18041        //The string table size needs to be a
//#endif                            //prime number that is somewhat larger
//#if BITS == 13                    //than 2**BITS.
//  #define TABLE_SIZE 9029
//#endif
//#if BITS <= 12
//  #define TABLE_SIZE 5021
//#endif

//int *code_value;                  //This is the code value array
//unsigned int *prefix_code;        //This array holds the prefix codes
//unsigned char *append_character;  //This array holds the appended chars
//unsigned char decode_stack[4000]; //This array holds the decoded string

//void compress(FILE *input,FILE *output);
//void compressBuffer(byte *input,int tam_buffer,byte *output);
//void expand(FILE *input,FILE *output);
//int find_match(int hash_prefix,unsigned int hash_character);
//void output_code(FILE *output,unsigned int code);
//unsigned int input_code(FILE *input);
//unsigned char *decode_string(unsigned char *buffer,unsigned int code);



void Mostrar_ayuda(void);
boolean Genera_mcr(char *cad_fichero);
int Calcula_numero_tarjetas(int numero_bytes);
boolean Detectar_pexe(unsigned char *buffer,int tam);
int Contar_ceros_final(unsigned char *buffer,int tam);
void Borrar_datos_mcr(unsigned char *buffer);
void Borrar_datos_exe(unsigned char *buffer);
//boolean Dejar_cabecera(unsigned char *buffer,int tam);
boolean Grabar_mcr(char *cad,unsigned char *memoria);

/********************************************************************/
int main(int argc,char **argv){
 if (argc<2) Mostrar_ayuda(); //Si no hay argumentos muestra ayuda
 else{//Le hemos pasado el nombre del programa .exe de la psone
  Genera_mcr(argv[1]);
  //Genera_mcr("fuego.exe");
  //Genera_mcr("mctool.exe");
 }

// FILE *input_file;
// FILE *output_file;
 //FILE *lzw_file;
// char input_file_name[81];
//  //The three buffers are needed for the compression phase.
//  code_value=(int*)malloc(TABLE_SIZE*sizeof(int));
//  prefix_code=(unsigned int *)malloc(TABLE_SIZE*sizeof(unsigned int));
//  append_character=(unsigned char *)malloc(TABLE_SIZE*sizeof(unsigned char));
//  if (code_value==NULL || prefix_code==NULL || append_character==NULL)
//  {
//    printf("Fatal error allocating table space!\n");
//    return(-1);
//  }
  //Get the file name, open it up, and open up the lzw output file.
//  if (argc>1)
//    strcpy(input_file_name,argv[1]);
//  else
//  {
//    printf("Input file name? ");
//    scanf("%s",input_file_name);
//  }
//  input_file=fopen(input_file_name,"rb");
  //input_file=fopen("fuego.exe","rb");
  //lzw_file=fopen("test.lzw","wb");
  //if (input_file==NULL || lzw_file==NULL)
  //{
  //  printf("Fatal error opening files.\n");
  //  return(-1);
  //};
  ////Compress the file.
  //compress(input_file,lzw_file);
//  fclose(input_file);
  //fclose(lzw_file);
//  free(code_value);
  ////Now open the files for the expansion.
  //lzw_file=fopen("test.lzw","rb");
  //output_file=fopen("test.out","wb");
  //if (output_file==NULL){
  // printf("Fatal error opening files.\n");
  // return(-2);
  //}
  //if (lzw_file==NULL || output_file==NULL)
  //{
  //  printf("Fatal error opening files.\n");
  //  return(-2);
  //};
  //Expand the file.
  //expand(lzw_file,output_file);
  //fclose(lzw_file);
 // fclose(output_file);

//  free(prefix_code);
//  free(append_character);



 return (0);
}

/*************************************************************/
void Mostrar_ayuda(void){
 printf("\nMCTOOL v1.0    Author: ackerman    Group: Sliders    24-01-2008\n");
 printf("-----------------------------------------------------------------\n");
 printf(" Allows you to create 1 or more memory card type .MCR files PSOne\n");
 printf(" in order to be read in the emulators or to be recorded on a real\n");
 printf(" MC.\n");
 printf(" Inside is the PSOne .EXE to be read with the PSXMCLOADER.\n");
 printf(" Warning! The .EXE must not exceed 1.900.000 Bytes.\n\n");
 printf(" Syntax:\n");
 printf("  mctool psx.exe\n");
}

/***********************************************************************/
boolean Genera_mcr(char *cad_fichero){
 //Crea o machaca los archivos .MCR con el .EXE de PSOne dentro
 FILE *fichero_lectura;
 char cad_aux[128],cad_numero[128];
 unsigned char buffer_lectura[max_buffer];
 unsigned char buffer_mcr[max_tarjeta];
 unsigned char *p_buffer; //El puntero al buffer
 int tam_fichero,i,j;
 //,ceros_final
 //int cont_memoria=0;
 int cont_exe=0;
 int total_tarjetas=0; //El numero total de tarjetas
 int cont_tarjetas=0;  //El contador de la tarjeta actual a grabar
 boolean cabecera_dejar=true;
 fichero_lectura=fopen(cad_fichero,"rb");
 if (fichero_lectura!=NULL){//Leer el fichero .EXE de origen
  Borrar_datos_exe(buffer_lectura);//Borra el buffer del EXE
  fseek(fichero_lectura,0,SEEK_END);
  tam_fichero=ftell(fichero_lectura); //Sacado el tamanio del fichero
  fseek(fichero_lectura,0,SEEK_SET);
  if ((tam_fichero>0)&&(tam_fichero<max_buffer)){
   if (fread(buffer_lectura,sizeof(unsigned char),tam_fichero,fichero_lectura) == tam_fichero){
    printf("File %s %d Bytes -- %d KB -- %d MB\n",cad_fichero,tam_fichero,tam_fichero/1024,tam_fichero/1048576);
    total_tarjetas= Calcula_numero_tarjetas(tam_fichero);
    printf("Card .MCR required: %d\n",total_tarjetas);
    if (Detectar_pexe(buffer_lectura,tam_fichero) != false){
     printf("PS-X EXE OK: -56 Bytes\n");
     Borrar_datos_mcr(memoria_array); //Borra los datos de la memoria .MCR
     //Cabecera 512 bytes MEMCARD FILE PSX
     printf("MC %c",memoria_array[offset_slot1-512]);
     printf("%c",memoria_array[offset_slot1-512+1]);
     printf(" Type %x",memoria_array[offset_slot1-512+2]);
     memoria_array[offset_slot1-512+3] = 15; //Fuerzo 15 bloques de memoria
     printf(" Blocks %d\n",memoria_array[offset_slot1-512+3]);
//     //Guardo los datos de la cabecera con tamanio y 0's
//     memoria_array[offset_slot1]= (tam_fichero>>16); //Guardo el tamanio del fichero
//     memoria_array[offset_slot1+1]= ((tam_fichero<<8)>>16);
//     memoria_array[offset_slot1+2]= (tam_fichero<<16)>>16;
//     //Direccion del salto 0x80010000 ejemplo 4 bytes
//     memoria_array[offset_slot1+3]= 0x00;
//     memoria_array[offset_slot1+4]= 0x00;
//     memoria_array[offset_slot1+5]= 0x01;
//     memoria_array[offset_slot1+6]= 0x80;

     //cont_memoria= 0;
     cont_exe= 0;
     //i= cabecera_propia; //7 bytes del tamanio fichero y salto
     //El primer slot tiene 512 bytes de cabacera para clu animaciones
     while ((cont_exe < tam_fichero)&&(i<tam_fichero)){
      memoria_array[offset_slot1+cont_exe]= buffer_lectura[cont_exe];
      cont_exe++;
     }

     if (Grabar_mcr("DISK1.mcr",memoria_array)==false){
      printf("An error occurred when recording the DISK1.MCR. Process aborted!\n");
      return(false);
     }
     else{
      cont_tarjetas++;
      printf("DISK1.MCR save OK. Card %d/%d\n",cont_tarjetas,total_tarjetas);
      for (j=1;j<total_tarjetas;j++){
       Borrar_datos_mcr(memoria_array); //Borra los datos de la memoria .MCR
       //Grabar el resto de tarjetas si hay.
       if (cont_exe < tam_fichero){ //Hay que grabar mas tarjetas
        i=offset_slot1; //Grabo slot1
        while ((cont_exe< tam_fichero)&&(i<=0x1FFFF)){
         memoria_array[i]=buffer_lectura[cont_exe];
         i++;cont_exe++;
        }
       }
       cont_tarjetas++;
       strcpy(cad_aux,"DISK");
       sprintf(cad_numero,"%d",cont_tarjetas);
       strcat(cad_aux,cad_numero);
       strcat(cad_aux,".mcr");
       if (Grabar_mcr(cad_aux,memoria_array)==false){
        printf("An error occurred while recording the DISK%d MCR. Process aborted!\n",cont_tarjetas);
        return(false);
       }
       else
        printf("DISK%d.MCR save OK. Card %d/%d\n",cont_tarjetas,cont_tarjetas,total_tarjetas);
      }//fin for j recorre el total de tarjetas
     }
    }
    else printf ("Not a correct PS-X EXE from PSOne\n");
    fclose(fichero_lectura);
    return(false);
   }//fin f_read
   else{
    fclose(fichero_lectura);
    printf("Error when reading the file in memory %s\n",cad_fichero);
    return(false);
   }//fin if fread
  }
  else{
   fclose(fichero_lectura);
   printf("The file length is too low or too high\n");
   return(false);
  }//fin del if tam_fichero
 }//fin fichero_lectura
 else{printf("Error when reading the source file %s\n",cad_fichero); return(false);}
}

/****************************************************************/
int Calcula_numero_tarjetas(int numero_bytes){
 //Le paso el numero de bytes del archivo y me dice el numero de tarjetas necesarias
 int aux,incrementa;
 if (numero_bytes<=(122880-offset_cabecera_mc-cabecera_propia)) return(1); //Le quitamos los 512 cabecera - 7 cabecera
 else{
  aux=numero_bytes-(122880-offset_cabecera_mc-cabecera_propia); //Para el resto de tarjetas que estan completas
  printf ("|%d |",aux);
  if (aux>0 && aux<(122880-offset_cabecera_mc-cabecera_propia)) incrementa=1;
  else incrementa=0;
  aux=(aux/(122880-offset_cabecera_mc-cabecera_propia));
//  printf ("|%d |",aux);
  if ((aux%(122880-offset_cabecera_mc-cabecera_propia))>0) aux++; //Se pasa de una tarjeta
//  printf ("|%d |",aux);
  aux++; //La tarjeta 1 inicial
  aux+=incrementa;
//  printf ("|%d |",aux);
  return(aux);
 }
}

/****************************************************************/
boolean Detectar_pexe(unsigned char *buffer,int tam){
 //Detecta si un ejecutable es de tipo PSOne de Sony
 boolean encontrado=true;
 if (buffer!=NULL){
  if (tam>3){//Comprueba si tiene la cadena PS-X
   if (buffer[0]!=0x50) encontrado=false;
   if (buffer[1]!=0x53) encontrado=false;
   if (buffer[2]!=0x2D) encontrado=false;
   if (buffer[3]!=0x58) encontrado=false;
   return(encontrado);
  }
  else return (false);
 }else return(false);
}

//*********************************************************************
int Contar_ceros_final(unsigned char *buffer,int tam){
 //Nos dice cuantos 0's hay al final del EXE para alinear. Si se pasa de
 //15 bits, 16383, se deja asi.
 int cont=0;
 boolean encontrado=false;
 if (buffer!=NULL){
  while (encontrado==false){
   if (buffer[tam-1]==0x0) cont++;
   else encontrado=true;
   tam--;
  }
 }
 if (cont>16383) cont=16383;
 return(cont);
}

//*********************************************************************
void Borrar_datos_mcr(unsigned char *buffer){
 //Borra los datos de los 15 slots de la memoria sin tocar las cabeceras
 int i,j;
 if (buffer!=NULL){
  for (i=offset_slot1;i<(offset_slot1+8192);i++) buffer[i]=0; //Borra Slot1
  for (j=1;j<14;j++){//El resto de los slots
   for (i=0;i<8192;i++) buffer[(j*8192)+i+offset_slot2]=0; //Borra los datos del slot
  }
 }
}

//*********************************************************************************
//boolean Dejar_cabecera(unsigned char *buffer,int tam){
// //Detecta si la cabecera del EXE de PSOne posee 0's o tiene datos importantes
// //Puede ser util para los EXE's empaquetados con UPX o casos similares
// int i;
// boolean aux=false;
// if (buffer!=NULL){
//  for (i=0x8;i<=0x0F;i++){if (buffer[i]!=0) aux=true;}
//  for (i=0x7C;i<=0x7FF;i++){if (buffer[i]!=0) aux=true;}
// }
// return (aux);
//}

//***********************************************************
boolean Grabar_mcr(char *cad,unsigned char *memoria){
 //Graba la memoria mcr
 FILE *fichero;
 boolean aux=false;
 if (cad!=NULL){
  fichero=fopen(cad,"wb");
  if (fichero!=NULL){
   if (fwrite(memoria,sizeof(unsigned char),max_tarjeta,fichero)!=max_tarjeta) aux=false;
   else aux=true;
   fclose(fichero);
  }
 }
 return (aux);
}

/************************************************************/
void Borrar_datos_exe(unsigned char *buffer){
 int i;
 for (i=0;i<max_buffer;i++) buffer[i]=0;
}




//********************************************************************
//* This is the compression routine.  The code should be a fairly close
//* match to the algorithm accompanying the article.
//********************************************************************
//void compress(FILE *input,FILE *output)
//{
//unsigned int next_code;
//unsigned int character;
//unsigned int string_code;
//unsigned int index;
//int i;
//
//  next_code=256;              //Next code is the next available string code
//  for (i=0;i<TABLE_SIZE;i++)  //Clear out the string table before starting
//    code_value[i]=-1;
//
//  i=0;
//  printf("Compressing...\n");
//  string_code=getc(input);    //Get the first code
//  //This is the main loop where it all happens.  This loop runs util all of
//  //the input has been exhausted.  Note that it stops adding codes to the
//  //table after all of the possible codes have been defined.
//  while ((character=getc(input)) != (unsigned)EOF)
//  {
//    if (++i==1000)                         //Print a * every 1000
//    {                                      //input characters.  This
//      i=0;                                 //is just a pacifier.
//      printf("*");
//    }
//    index=find_match(string_code,character); //See if the string is in
//    if (code_value[index] != -1)             //the table. If it is,
//      string_code=code_value[index];         //get the code value. If
//    else                                     //the string is not in the
//    {                                        //table, try to add it.
//      if (next_code <= MAX_CODE)
//      {
//        code_value[index]=next_code++;
//        prefix_code[index]=string_code;
//        append_character[index]=character;
//      }
//      output_code(output,string_code);  //When a string is found
//      string_code=character;            //that is not in the table
//    }                                   //I output the last string
//  }                                     //after adding the new one
//  // End of the main loop.
//  output_code(output,string_code); //Output the last code
//  output_code(output,MAX_VALUE);   //Output the end of buffer code
//  output_code(output,0);           //This code flushes the output buffer
//  printf("\n");
//}

//********************************************************************
//void compressBuffer(byte *input,int tam_buffer,byte *output)
//{ //Idem Compress files but with buffer
//  unsigned int next_code;
//  unsigned int character;
//  unsigned int string_code;
//  unsigned int index;
//  int cont_buffer=0;
//  int i;
//
//  next_code=256;              //Next code is the next available string code
//  for (i=0;i<TABLE_SIZE;i++)  //Clear out the string table before starting
//    code_value[i]=-1;
//  i=0;
//  printf("Compressing Buffer...\n");
//  string_code=input[cont_buffer];    //Get the first code
//  cont_buffer++;
//  //This is the main loop where it all happens.  This loop runs util all of
//  //the input has been exhausted.  Note that it stops adding codes to the
//  //table after all of the possible codes have been defined.
//  while (cont_buffer< tam_buffer)
//  {
//    if (++i==1000)                         //Print a * every 1000
//    {                                      //input characters.  This
//      i=0;                                 //is just a pacifier.
//      printf("*");
//    }
//    index=find_match(string_code,character); //See if the string is in
//    if (code_value[index] != -1)             //the table. If it is,
//      string_code=code_value[index];         //get the code value. If
//    else                                     //the string is not in the
//    {                                        //table, try to add it.
//      if (next_code <= MAX_CODE)
//      {
//        code_value[index]=next_code++;
//        prefix_code[index]=string_code;
//        append_character[index]=character;
//      }
//      //output_code(output,string_code);  //When a string is found
//      string_code=character;            //that is not in the table
//    }                                   //I output the last string
//    cont_buffer++;
//  }                                     //after adding the new one
//  // End of the main loop.
//  //output_code(output,string_code); //Output the last code
//  //output_code(output,MAX_VALUE);   //Output the end of buffer code
//  //output_code(output,0);           //This code flushes the output buffer
//  printf("\n");
//}

//*****************************************************************************
//* This is the hashing routine. It tries to find a match for the prefix+char *
//* string in the string table. If it finds it, the index is returned. If     *
//* the string is not found, the first available index in the string table is *
//* returned instead.                                                         *
//*****************************************************************************
//int find_match(int hash_prefix,unsigned int hash_character)
//{
//int index;
//int offset;
//
//  index = (hash_character << HASHING_SHIFT) ^ hash_prefix;
//  if (index == 0)
//    offset = 1;
//  else
//    offset = TABLE_SIZE - index;
//  while (1)
//  {
//    if (code_value[index] == -1)
//      return(index);
//    if (prefix_code[index] == hash_prefix &&
//        append_character[index] == hash_character)
//      return(index);
//    index -= offset;
//    if (index < 0)
//      index += TABLE_SIZE;
//  }
//}

//****************************************************************************
//* This is the expansion routine.  It takes an LZW format file, and expands *
//* it to an output file.  The code here should be a fairly close match to   *
//* the algorithm in the accompanying article.                               *
//****************************************************************************
//void expand(FILE *input,FILE *output)
//{
//unsigned int next_code;
//unsigned int new_code;
//unsigned int old_code;
//int character;
//int counter;
//unsigned char *string;
//
//  next_code=256;           // This is the next available code to define
//  counter=0;               // Counter is used as a pacifier.
//  printf("Expanding...\n");
//
//  old_code=input_code(input);  // Read in the first code, initialize the
//  character=old_code;          // character variable, and send the first
//  putc(old_code,output);       // code to the output file
//  //This is the main expansion loop.  It reads in characters from the LZW file
//  //until it sees the special code used to inidicate the end of the data.
//  while ((new_code=input_code(input)) != (MAX_VALUE))
//  {
//    if (++counter==1000)   // This section of code prints out
//    {                      // an asterisk every 1000 characters
//      counter=0;           // It is just a pacifier.
//      printf("*");
//    }
//  //This code checks for the special STRING+CHARACTER+STRING+CHARACTER+STRING
//  //case which generates an undefined code.  It handles it by decoding
//  //the last code, and adding a single character to the end of the decode string.
//    if (new_code>=next_code)
//    {
//      *decode_stack=character;
//      string=decode_string(decode_stack+1,old_code);
//    }
//  //Otherwise we do a straight decode of the new code.
//    else
//      string=decode_string(decode_stack,new_code);
//
//  //Now we output the decoded string in reverse order.
//    character=*string;
//    while (string >= decode_stack)
//      putc(*string--,output);
//
// //Finally, if possible, add a new code to the string table.
//
//    if (next_code <= MAX_CODE)
//    {
//      prefix_code[next_code]=old_code;
//      append_character[next_code]=character;
//      next_code++;
//    }
//    old_code=new_code;
//  }
//  printf("\n");
//}

//***********************************************************************
//* This routine simply decodes a string from the string table, storing *
//* it in a buffer.  The buffer can then be output in reverse order by  *
//* the expansion program.                                              *
//***********************************************************************
//unsigned char *decode_string(unsigned char *buffer,unsigned int code)
//{
//int i;
//
//  i=0;
//  while (code > 255)
//  {
//    *buffer++ = append_character[code];
//    code=prefix_code[code];
//    if (i++>=MAX_CODE)
//    {
//      printf("Fatal error during code expansion.\n");
//      exit(-3);
//    }
//  }
//  *buffer=code;
//  return(buffer);
//}

//*****************************************************************
//* The following two routines are used to output variable length *
//* codes.  They are written strictly for clarity, and are not    *
//* particularyl efficient.                                       *
//*****************************************************************
//unsigned int input_code(FILE *input)
//{
//unsigned int return_value;
//static int input_bit_count=0;
//static unsigned long input_bit_buffer=0L;
//
//  while (input_bit_count <= 24)
//  {
//    input_bit_buffer |=
//        (unsigned long) getc(input) << (24-input_bit_count);
//    input_bit_count += 8;
//  }
//  return_value=input_bit_buffer >> (32-BITS);
//  input_bit_buffer <<= BITS;
//  input_bit_count -= BITS;
//  return(return_value);
//}

//*******************************************************************
//void output_code(FILE *output,unsigned int code)
//{
//static int output_bit_count=0;
//static unsigned long output_bit_buffer=0L;
//
//  output_bit_buffer |= (unsigned long) code << (32-BITS-output_bit_count);
//  output_bit_count += BITS;
//  while (output_bit_count >= 8)
//  {
//    putc(output_bit_buffer >> 24,output);
//    output_bit_buffer <<= 8;
//    output_bit_count -= 8;
//  }
//}


//Deprecated
//while ((cont_exe<(tam_fichero-ceros_final))&&(i<=0x1FFFF)){


     //ceros_final=Contar_ceros_final(buffer_lectura,tam_fichero);
     //printf("Total 0's: -%d Bytes\n",ceros_final);


//j++;

//memoria_array[offset_slot1+i-512]= buffer_lectura[cont_exe];


     //memoria_array[offset_slot1+3]=(ceros_final>>8); //Guardo los 0's
     //memoria_array[offset_slot1+4]=((ceros_final<<8)>>8);
     //cabecera_dejar=Dejar_cabecera(buffer_lectura,tam_fichero);



     //if (cabecera_dejar==true){
     // printf("La cabecera del EXE se incluye dentro de la MCR +1932 Bytes\n");
      //memoria_array[offset_slot1+3]=memoria_array[offset_slot1+3]|0x40; //Activa el bit de cabecera
//      for (i=0x8;i<=0x0F;i++){
//       memoria_array[offset_slot1+cabecera_loader+i-0x8]= buffer_lectura[i];
//       cont_memoria++;
//      }
//      for (i=0x7C;i<=0x7FF;i++){
//       memoria_array[offset_slot1+cabecera_loader+i-0x7C]= buffer_lectura[i];
//       cont_memoria++;
//      }
     //}
     //else{
     // printf("La cabecera del EXE se ha borrado de la MCR -1932 Bytes\n");
     //}//fin if cabecera_dejar
     //Meto el resto de datos del slot1
//     for (i=0x10;i<=0x4B;i++)
//      memoria_array[offset_slot1+i-0x10+cabecera_loader+cont_memoria]= buffer_lectura[i];
//     cont_memoria+=0x3C;
     //i=cont_memoria+cabecera_loader+512;
     //i= cabecera_loader;
     //j= 0;
//     cont_exe=0x800; //2048 de la cabecera
     //while ((cont_exe<(tam_fichero-ceros_final))&&(i<8192)){
